import UserList from "../components/Home/UserList"

const Home = () => {
    return (
        <>
            <UserList />
        </>
    )
}

export default Home