const Users = [
    {
        index: 1,
        useername: "Krishna",
        profile: "https://images.unsplash.com/photo-1603726656278-0a758b4ae426?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxjb2xsZWN0aW9uLXBhZ2V8MXw0ODIwNzk0Nnx8ZW58MHx8fHx8&auto=format&fit=crop&w=800&q=60"
    },
    {
        index: 2,
        useername: "Shrddha",
        profile: "https://images.unsplash.com/photo-1696219364293-e38483602e49?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHw1MHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=60"
    },
    {
        index: 3,
        useername: "Vasuki",
        profile: "https://images.unsplash.com/photo-1682686579688-c2ba945eda0e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHwzMXx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=60"
    },
    {
        index: 4,
        useername: "Rajvi",
        profile: "https://images.unsplash.com/photo-1695642579321-fcb1fc79b976?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHw5fHx8ZW58MHx8fHx8&auto=format&fit=crop&w=800&q=60"
    },
    {
        index: 5,
        useername: "Ritika",
        profile: "https://images.unsplash.com/photo-1695783455299-5f031bce65e8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHwxNXx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=60"
    }
]

export default Users